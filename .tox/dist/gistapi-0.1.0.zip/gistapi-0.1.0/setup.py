import setuptools

setuptools.setup(
    name="gistapi",
    version="0.1.0",
    packages=["gistapi"],
    test_suite="tests",
)
